<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <!-- Custom fonts for this template-->
     <link href="css/style.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div id="myModal" class="modal2">
    <span class="close">&times;</span>
    <img class="modal-content2" id="fullPicture" src="../fdl/img/offer.jpeg">
    
</div>
<style>
  #picture{
   
    cursor: pointer;
    transition: 0.3s;

}

#picture:hover{
    opacity: 0.8s;
    box-shadow: 0 0 4px black;
}

.modal2{
    display: none;
    position: fixed;
    z-index: 1;
    padding-top: 100px;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgb(0, 0,0);
    background-color: rgba(0, 0, 0, 0.9);
}

.modal-content2{
    margin: auto;
    display: block;
    width: 24%;
    max-width: 700px;
    text-align: center;
    color: #ccc;
    padding: 10px 0;
    height: 500px;
}

.modal-content2,#caption{
    -webkit-animation-name: zoom;
    -webkit-animation-duration: 0.8s;
    animation-name: zoom;
    animation-duration: 0.8s;
}

@-webkit-keyframes zoom{
    from{-webkit-transform: scale(0);}
    to{-webkit-transform: scale(1);}
}

@keyframes zoom {
from{transform:scale(0);}    
to{transform: scale(1);}
}

@media only screen and(max-width:700px){
    .modal-content2{
    margin: auto;
    display: block;
    width: 24%;
    max-width: 700px;
    text-align: center;
    color: #ccc;
    padding: 10px 0;
    height: 500px;
    }
}

.close{
    position:absolute;
    top: 15px;
    right: 35px;
    color: #f1f1f1;
    font-size: 50px;
    font-weight: bold;
    transition: 0.3s;
}

.close:hover
.close:focus{
color: #bbb;
text-decoration: none;
cursor: pointer;

}
</style>
  <script>
    
    var modal = document.getElementById("myModal");
    var img = document.getElementById("picture");
    var modalImg = document.getElementById("fullPicture");
    var captionText = document.getElementById("caption");

    // img.onclick=function(){
    //   modal.style.display="block";
    //   modalImg.src=this.src;
    //   captionText.innerHTML=this.alt;
    // }

    window.onload = function() {
    // Select the modal and image
    var modal = document.getElementById('myModal');
    var modalImg = document.getElementById('fullPicture');
    if (performance.navigation.type === 1 && performance.navigation.redirectCount === 0){
    // Set the image source and display the modal
    modal.style.display = 'block';
    modalImg.src = '../fdl/img/offer.jpeg';
    }
  };

   
    var span=document.getElementsByClassName("close")[0];

    span.onclick=function(){
      modal.style.display="none";
    }
  </script>
  
</body>
</html>