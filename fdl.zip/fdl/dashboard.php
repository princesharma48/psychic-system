<?php
session_start();
include("connect.php");


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION["adminemailid"])) {
    header("location:login.php");
}
include("modal.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin Panel-Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>

<div class="header">

    <body id="page-top">

        <style>
            .header {
                font-family: "Poppins";
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0 60px;
                background-color: #204969;
            }

            .log {
                color: white;
                border-radius: 6px;
                background: black;
            }
        </style>

</div>
<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include("sidebar.php"); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include("header.php");?> 
            <!-- End of Topbar -->
            <!-- Page Heading -->
            <h1 class="h3 mb-2 text-gray-800">Offer</h1>
            <style>
  #picture{
   
    cursor: pointer;
    transition: 0.3s;

}

#picture:hover{
    opacity: 0.8s;
    box-shadow: 0 0 4px black;
}

.modal2{
    display: none;
    position: fixed;
    z-index: 1;
    padding-top: 100px;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgb(0, 0,0);
    background-color: rgba(0, 0, 0, 0.9);
}

.modal-content2{
    margin: auto;
    display: block;
    width: 24%;
    max-width: 700px;
    text-align: center;
    color: #ccc;
    padding: 10px 0;
    height: 500px;
}

.modal-content2,#caption{
    -webkit-animation-name: zoom;
    -webkit-animation-duration: 0.8s;
    animation-name: zoom;
    animation-duration: 0.8s;
}

@-webkit-keyframes zoom{
    from{-webkit-transform: scale(0);}
    to{-webkit-transform: scale(1);}
}

@keyframes zoom {
from{transform:scale(0);}    
to{transform: scale(1);}
}

@media only screen and(max-width:700px){
    .modal-content2{
    margin: auto;
    display: block;
    width: 24%;
    max-width: 700px;
    text-align: center;
    color: #ccc;
    padding: 10px 0;
    height: 500px;
    }
}

.close{
    position:absolute;
    top: 15px;
    right: 35px;
    color: #f1f1f1;
    font-size: 50px;
    font-weight: bold;
    transition: 0.3s;
}

.close:hover
.close:focus{
color: #bbb;
text-decoration: none;
cursor: pointer;

}
</style>
</head>

<body>
  <img id="picture" src="../fdl/img/offer.jpeg" alt="" style="width: 100%; max-width: 200px; display: flex; margin: auto;">
  <br>
</body>
            
            <div class="container1">
                <div class="image-box text-center">
                   <h1 class=text-center>I-Phone 15</h1>
                   <input type="radio" id="image-1" name="image" checked>
                   <input type="radio" id="image-2" name="image">
                   <input type="radio" id="image-3" name="image">
                   <input type="radio" id="image-4" name="image">
                    <!-- <img class="oimg" src="img/1.png" alt="img" checked>
                    <img class="oimg" src="img/2.png" alt="img">
                    <img class="oimg" src="img/3.png" alt="img">
                    <img class="oimg" src="img/4.png" alt="img"> -->
                    <div class="image-bg"></div>
                </div>
            </div>

            <!-- Footer -->
            <?php include("footer.php"); ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"></span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

    <script src="index.js"></script>

    </body>

</html>